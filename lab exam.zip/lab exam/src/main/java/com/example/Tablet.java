package com.example;



import javax.persistence.Entity;

@Entity
public class Tablet extends Smartphone {
    private boolean hasStylus;
    private double screenSize;

    // Getters and Setters
    public boolean isHasStylus() {
        return hasStylus;
    }

    public void setHasStylus(boolean hasStylus) {
        this.hasStylus = hasStylus;
    }

    public double getScreenSize() {
        return screenSize;
    }

    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }
}
